﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PopcornStudio.MetroTrainInterop
{
    public class ThroughPathNode
    {
        public string StationName { get; set; }
    }
}
